/**
 * pages/Balistica/Balistica.tsx
 * Asistente balístico — glass, fondo MA.png, cálculos básicos y avanzados, trayectoria.
 *
 * Ruta: <Route path="/balistica" element={<Balistica />} />
 * Fondo: public/images/backgrounds/MA.png  (antes Estilos/Assest/MA.png)
 */
import { useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';

type System = 'metric' | 'imperial';
type Entry = { id: string; at: string; title: string; result: string };

const G = 9.80665;
const GR_PER_KG = 15432.3584;

function n(v: string, name: string): number {
  const x = Number(String(v).replace(',', '.'));
  if (!Number.isFinite(x)) throw new Error(`«${name}» no es un número`);
  return x;
}
function fmt(x: number, d = 4): string {
  if (!Number.isFinite(x)) return '—';
  const abs = Math.abs(x);
  if (x !== 0 && (abs >= 1e8 || abs < 1e-4)) return x.toExponential(4);
  return String(Number(x.toPrecision(d + 2)));
}

const lenToM: Record<string, number> = {
  nm: 1e-9, mm: 1e-3, cm: 0.01, m: 1, km: 1000, in: 0.0254, ft: 0.3048, yd: 0.9144, mi: 1609.344,
};

export default function Balistica() {
  const navigate = useNavigate();
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [system, setSystem] = useState<System>('metric');
  const [open, setOpen] = useState<Record<string, boolean>>({
    units: true, bullet: true, gun: false, env: false, basic: true, adv: false, out: true, hist: false, explain: false,
  });
  const [msg, setMsg] = useState('Completa un cálculo para ver el resultado y la trayectoria.');
  const [history, setHistory] = useState<Entry[]>([]);
  const [form, setForm] = useState<Record<string, string>>({});
  const [zoom, setZoom] = useState(1);

  useEffect(() => {
    try {
      const raw = localStorage.getItem('rbc-balistica-hist');
      if (raw) setHistory(JSON.parse(raw));
    } catch { /* ignore */ }
  }, []);
  useEffect(() => {
    try { localStorage.setItem('rbc-balistica-hist', JSON.stringify(history.slice(0, 12))); } catch { /* ignore */ }
  }, [history]);

  const u = useMemo(() => {
    const m = system === 'metric';
    return {
      mass: m ? 'kg' : 'granos',
      len: m ? 'm' : 'yd',
      small: m ? 'mm' : 'in',
      vel: m ? 'm/s' : 'ft/s',
      temp: m ? '°C' : '°F',
      press: m ? 'Pa' : 'inHg',
      wind: m ? 'm/s' : 'mph',
    };
  }, [system]);

  const set = (id: string, value: string) => setForm((s) => ({ ...s, [id]: value }));
  const val = (id: string) => form[id] ?? '';

  const push = (title: string, result: string) => {
    setMsg(result);
    setHistory((h) => [{ id: `${Date.now()}`, at: new Date().toLocaleString('es'), title, result }, ...h].slice(0, 12));
    setOpen((s) => ({ ...s, out: true }));
  };

  const massKg = (raw: string, label: string) => {
    const x = n(raw, label);
    return system === 'metric' ? x : x / GR_PER_KG;
  };
  const velMs = (raw: string, label: string) => {
    const x = n(raw, label);
    return system === 'metric' ? x : x * 0.3048;
  };
  const lenM = (raw: string, label: string, imperialUnit: keyof typeof lenToM = 'yd') => {
    const x = n(raw, label);
    return system === 'metric' ? x : x * lenToM[imperialUnit];
  };

  const draw = (v0: number, angleDeg: number, rangeM: number) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const w = canvas.width;
    const h = canvas.height;
    ctx.clearRect(0, 0, w, h);
    ctx.fillStyle = 'rgba(8,8,12,0.35)';
    ctx.fillRect(0, 0, w, h);
    const rad = (angleDeg * Math.PI) / 180;
    const vx = v0 * Math.cos(rad);
    const vy = v0 * Math.sin(rad);
    const pts: { x: number; y: number }[] = [];
    const tMax = Math.max(rangeM / Math.max(vx, 0.001) * 1.35, 0.2);
    for (let i = 0; i <= 180; i++) {
      const t = (tMax * i) / 180;
      const x = vx * t;
      const y = vy * t - 0.5 * G * t * t;
      pts.push({ x, y });
      if (y < -0.5 && i > 8) break;
    }
    const maxX = Math.max(rangeM * 1.05, ...pts.map((p) => p.x), 1) / zoom;
    const ys = pts.map((p) => p.y);
    const minY = Math.min(0, ...ys);
    const maxY = Math.max(1, ...ys);
    const pad = 36;
    const sx = (w - pad * 2) / maxX;
    const sy = (h - pad * 2) / (maxY - minY || 1);
    const X = (x: number) => pad + x * sx;
    const Y = (y: number) => h - pad - (y - minY) * sy;
    ctx.strokeStyle = 'rgba(255,255,255,0.18)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(pad, Y(0));
    ctx.lineTo(w - 12, Y(0));
    ctx.moveTo(pad, pad);
    ctx.lineTo(pad, h - pad);
    ctx.stroke();
    ctx.strokeStyle = '#ff4d4d';
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    pts.forEach((p, i) => {
      const cx = X(p.x);
      const cy = Y(p.y);
      if (i === 0) ctx.moveTo(cx, cy);
      else ctx.lineTo(cx, cy);
    });
    ctx.stroke();
    const tHit = vx === 0 ? 0 : rangeM / vx;
    const yHit = vy * tHit - 0.5 * G * tHit * tHit;
    ctx.fillStyle = '#fff';
    ctx.beginPath();
    ctx.arc(X(Math.min(rangeM, maxX)), Y(yHit), 5, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,0.75)';
    ctx.font = '12px ui-monospace, monospace';
    ctx.fillText(system === 'metric' ? 'distancia (m)' : 'distancia (escala m)', w / 2 - 40, h - 10);
  };

  const runBasic = (kind: string) => {
    try {
      let title = kind;
      let result = '';
      if (kind === 'moa') {
        const dist = lenM(val('moaD'), 'distancia', 'yd');
        const size = system === 'metric' ? n(val('moaS'), 'tamaño') / 1000 : n(val('moaS'), 'tamaño') * 0.0254;
        if (dist <= 0) throw new Error('La distancia debe ser mayor que 0');
        const moa = ((size / dist) * (180 / Math.PI) * 60);
        title = 'MOA';
        result = `${fmt(moa, 3)} MOA  ·  ${fmt(moa * 1.047, 3)} in a 100 yd equivalentes por MOA de grupo`;
      } else if (kind === 'drop') {
        const v = velMs(val('dropV'), 'velocidad');
        const d = lenM(val('dropD'), 'distancia', 'yd');
        if (v <= 0) throw new Error('La velocidad debe ser mayor que 0');
        const t = d / v;
        const drop = 0.5 * G * t * t;
        title = 'Caída';
        result = `Caída ≈ ${fmt(drop)} m  (${fmt(drop / 0.0254)} in) en ${fmt(t, 3)} s, sin resistencia del aire.`;
        draw(v, 0, d);
      } else if (kind === 'wind') {
        const w = system === 'metric' ? n(val('windV'), 'viento') : n(val('windV'), 'viento') * 0.44704;
        const v = velMs(val('windBv'), 'velocidad');
        const d = lenM(val('windD'), 'distancia', 'yd');
        if (v <= 0) throw new Error('Velocidad inválida');
        const t = d / v;
        const drift = w * t;
        title = 'Deriva';
        result = `Deriva lateral aproximada ${fmt(drift)} m si el viento cruzado actúa todo el vuelo (${fmt(t, 3)} s). Es un límite superior simple, no un modelo BC.`;
      } else if (kind === 'energy') {
        const m = massKg(val('enM'), 'masa');
        const v = velMs(val('enV'), 'velocidad');
        title = 'Energía';
        result = `${fmt(0.5 * m * v * v)} J`;
      } else if (kind === 'tof') {
        const v = velMs(val('tofV'), 'velocidad');
        const d = lenM(val('tofD'), 'distancia', 'yd');
        if (v <= 0) throw new Error('Velocidad inválida');
        title = 'Tiempo de vuelo';
        result = `${fmt(d / v, 4)} s  (velocidad constante)`;
      } else if (kind === 'inertia') {
        const m = massKg(val('inM'), 'masa');
        const r = system === 'metric' ? n(val('inR'), 'radio') : n(val('inR'), 'radio') * 0.0254;
        title = 'Momento de inercia';
        result = `${fmt((2 / 5) * m * r * r)} kg·m²  (esfera sólida)`;
      } else if (kind === 'force') {
        const m = massKg(val('fM'), 'masa');
        const a = n(val('fA'), 'aceleración');
        title = 'Fuerza';
        result = `${fmt(m * a)} N`;
      } else if (kind === 'traj') {
        const ang = n(val('trA'), 'ángulo');
        const v = velMs(val('trV'), 'velocidad');
        const x = lenM(val('trX'), 'distancia', 'm');
        const rad = (ang * Math.PI) / 180;
        const y = x * Math.tan(rad) - (G * x * x) / (2 * v * v * Math.cos(rad) ** 2);
        title = 'Trayectoria';
        result = `Altura en x = ${fmt(x)} m: ${fmt(y)} m. Vacío, sin rozamiento.`;
        draw(v, ang, x);
      } else if (kind === 'elev') {
        const h = lenM(val('elH'), 'altura', 'm');
        const d = lenM(val('elD'), 'distancia', 'm');
        if (d === 0) throw new Error('Distancia 0');
        title = 'Elevación';
        result = `${fmt((Math.atan(h / d) * 180) / Math.PI)}°`;
      } else if (kind === 'grav') {
        const m1 = massKg(val('g1'), 'masa 1');
        const m2 = massKg(val('g2'), 'masa 2');
        const unit = val('gU') || 'm';
        const dist = n(val('gD'), 'distancia') * (lenToM[unit] ?? 1);
        if (dist <= 0) throw new Error('Distancia inválida');
        const F = (6.6743e-11 * m1 * m2) / (dist * dist);
        title = 'Gravedad';
        result = `${fmt(F)} N`;
      } else if (kind === 'coriolis') {
        const v = velMs(val('coV'), 'velocidad');
        const t = n(val('coT'), 'tiempo');
        const a = n(val('coA'), 'aceleración lateral');
        const traveled = v * t;
        const lateral = 0.5 * a * t * t;
        title = 'Desvío lateral';
        result = `En ${fmt(t)} s recorre ${fmt(traveled)} m. El desvío por la aceleración lateral escrita es ${fmt(lateral)} m. La aceleración de Coriolis real depende de la latitud y del rumbo.`;
      } else {
        throw new Error('Cálculo no disponible');
      }
      push(title, result);
    } catch (e) {
      setMsg(e instanceof Error ? e.message : 'Error');
    }
  };

  const runAdvanced = () => {
    try {
      const mass = massKg(val('bMass'), 'masa');
      const bc = n(val('bBC'), 'BC');
      const calIn = system === 'metric' ? n(val('bCal'), 'calibre') / 25.4 : n(val('bCal'), 'calibre');
      const v0 = velMs(val('gMv'), 'velocidad inicial');
      const dist = lenM(val('aDist'), 'distancia', 'yd');
      const angle = n(val('aAng') || '0', 'ángulo');
      const tempC = system === 'metric' ? n(val('eT') || '15', 'temperatura') : (n(val('eT') || '59', 'temperatura') - 32) * 5 / 9;
      const pressurePa = system === 'metric' ? n(val('eP') || '101325', 'presión') : n(val('eP') || '29.92', 'presión') * 3386.389;
      const humidity = n(val('eH') || '50', 'humedad');
      const wind = system === 'metric' ? n(val('eW') || '0', 'viento') : n(val('eW') || '0', 'viento') * 0.44704;
      const windDir = n(val('eWd') || '90', 'rumbo del viento');
      if (v0 <= 0 || dist <= 0 || calIn <= 0) throw new Error('Velocidad, distancia y calibre deben ser mayores que 0');
      const Tk = tempC + 273.15;
      const sat = 610.78 * Math.exp((17.27 * tempC) / (tempC + 237.3));
      const vapor = (humidity / 100) * sat;
      const rho = ((pressurePa - vapor) * 0.0289644 + vapor * 0.018016) / (8.314462618 * Tk / 0.0289644);
      const air = Number.isFinite(rho) && rho > 0 ? rho : pressurePa / (287.05 * Tk);
      const diameter = calIn * 0.0254;
      const area = Math.PI * (diameter / 2) ** 2;
      const i = Math.max(0.2, 1 / Math.max(bc, 0.05));
      const Cd = 0.3 * i;
      const drag = 0.5 * air * Cd * area;
      const vFinal = v0 / (1 + (drag * dist) / Math.max(mass, 1e-6));
      const vAvg = (v0 + Math.max(vFinal, 0)) / 2;
      const tof = dist / Math.max(vAvg, 0.01);
      const drop = 0.5 * G * tof * tof;
      const cross = wind * Math.sin((windDir * Math.PI) / 180);
      const drift = cross * tof * (1 - Math.max(vFinal, 0) / v0);
      const energy = 0.5 * mass * Math.max(vFinal, 0) ** 2;
      const twist = system === 'metric' ? n(val('gTwist') || '254', 'paso') / 25.4 : n(val('gTwist') || '10', 'paso');
      const lengthCal = 4;
      const grains = mass * GR_PER_KG;
      const sg = (30 * grains) / (twist ** 2 * calIn ** 3 * lengthCal * (1 + lengthCal ** 2));
      const stable = sg > 1.5 ? 'estable' : sg > 1 ? 'marginal' : 'inestable';
      const rad = (angle * Math.PI) / 180;
      const eq = `y(x) = ${fmt(Math.tan(rad), 4)} x − ${fmt(G / (2 * (v0 * Math.cos(rad)) ** 2), 6)} x²`;
      const result = [
        `Caída (vacío, tiempo de vuelo medio): ${fmt(drop)} m`,
        `Deriva de viento cruzado (modelo corto): ${fmt(drift)} m`,
        `Tiempo de vuelo: ${fmt(tof, 4)} s`,
        `Velocidad final estimada: ${fmt(vFinal)} m/s`,
        `Energía de impacto: ${fmt(energy)} J`,
        `Densidad del aire: ${fmt(air, 4)} kg/m³`,
        `Estabilidad Miller aproximada: ${stable} (SG ${fmt(sg, 3)})`,
        `Ecuación sin rozamiento: ${eq}`,
        'El arrastre es una estimación Cd·BC, no una tabla G1 completa.',
      ].join('\n');
      push('Avanzado', result);
      draw(v0, angle, dist);
    } catch (e) {
      setMsg(e instanceof Error ? e.message : 'Error');
    }
  };

  const Field = ({ id, label, ph }: { id: string; label: string; ph?: string }) => (
    <label className="field">
      <span>{label}</span>
      <input value={val(id)} placeholder={ph} inputMode="decimal" onChange={(e) => set(id, e.target.value)} />
    </label>
  );

  const Section = ({ id, title, children }: { id: string; title: string; children: React.ReactNode }) => (
    <section className="sec">
      <button type="button" className="sec-h" onClick={() => setOpen((s) => ({ ...s, [id]: !s[id] }))}>
        <span>{title}</span><span>{open[id] ? '▴' : '▾'}</span>
      </button>
      {open[id] && <div className="sec-b">{children}</div>}
    </section>
  );

  return (
    <>
      <style>{CSS}</style>
      <div className="bl-page">
        <header className="bl-head">
          <button type="button" className="icon" onClick={() => navigate('/calcular')}>←</button>
          <h1>Balística</h1>
          <button type="button" className="ghost" onClick={() => navigate('/proyectos')}>Proyectos</button>
        </header>
        <main className="bl-main">
          <Section id="units" title="Unidades">
            <div className="row">
              <button type="button" className={system === 'metric' ? 'chip on' : 'chip'} onClick={() => setSystem('metric')}>Métrico</button>
              <button type="button" className={system === 'imperial' ? 'chip on' : 'chip'} onClick={() => setSystem('imperial')}>Imperial</button>
            </div>
            <p className="note">Masa {u.mass} · distancia larga {u.len} · calibres {u.small} · velocidad {u.vel}. Los resultados de energía y fuerza salen en joules y newtons.</p>
          </Section>

          <Section id="bullet" title="Datos de la bala">
            <div className="cols">
              <Field id="bMass" label={`Masa (${u.mass})`} ph={system === 'metric' ? '0.010' : '150'} />
              <Field id="bCal" label={`Calibre (${u.small})`} ph={system === 'metric' ? '7.82' : '0.308'} />
              <Field id="bBC" label="Coeficiente G1" ph="0.435" />
              <Field id="bDia" label={`Diámetro (${u.small})`} ph={system === 'metric' ? '7.82' : '0.308'} />
            </div>
          </Section>

          <Section id="gun" title="Datos del arma">
            <div className="cols">
              <Field id="gMv" label={`Velocidad inicial (${u.vel})`} ph={system === 'metric' ? '850' : '2800'} />
              <Field id="gLen" label={`Longitud del cañón (${u.small})`} ph={system === 'metric' ? '610' : '24'} />
              <Field id="gTwist" label={`Paso de estría (1:${u.small})`} ph={system === 'metric' ? '254' : '10'} />
            </div>
          </Section>

          <Section id="env" title="Ambiente">
            <div className="cols">
              <Field id="eT" label={`Temperatura (${u.temp})`} ph={system === 'metric' ? '15' : '59'} />
              <Field id="eP" label={`Presión (${u.press})`} ph={system === 'metric' ? '101325' : '29.92'} />
              <Field id="eH" label="Humedad (%)" ph="50" />
              <Field id="eAlt" label={`Altitud (${system === 'metric' ? 'm' : 'ft'})`} ph="0" />
              <Field id="eW" label={`Viento (${u.wind})`} ph="0" />
              <Field id="eWd" label="Dirección del viento (°)" ph="90" />
            </div>
          </Section>

          <Section id="basic" title="Cálculos básicos">
            <article className="card">
              <h3>MOA</h3>
              <p>Minuto de ángulo real: tamaño / distancia, en minutos de arco. 1 MOA ≈ 1.047 in a 100 yd.</p>
              <div className="cols">
                <Field id="moaD" label={`Distancia (${u.len})`} />
                <Field id="moaS" label={`Tamaño del grupo (${u.small})`} />
              </div>
              <button type="button" className="go" onClick={() => runBasic('moa')}>Calcular MOA</button>
            </article>
            <article className="card">
              <h3>Caída sin rozamiento</h3>
              <div className="cols">
                <Field id="dropV" label={`Velocidad (${u.vel})`} />
                <Field id="dropD" label={`Distancia (${u.len})`} />
              </div>
              <button type="button" className="go" onClick={() => runBasic('drop')}>Calcular caída</button>
            </article>
            <article className="card">
              <h3>Deriva por viento cruzado</h3>
              <div className="cols">
                <Field id="windBv" label={`Velocidad de la bala (${u.vel})`} />
                <Field id="windV" label={`Viento (${u.wind})`} />
                <Field id="windD" label={`Distancia (${u.len})`} />
              </div>
              <button type="button" className="go" onClick={() => runBasic('wind')}>Calcular deriva</button>
            </article>
            <article className="card">
              <h3>Energía, tiempo, inercia y fuerza</h3>
              <div className="cols">
                <Field id="enM" label={`Masa (${u.mass})`} />
                <Field id="enV" label={`Velocidad (${u.vel})`} />
              </div>
              <button type="button" className="go slim" onClick={() => runBasic('energy')}>Energía</button>
              <div className="cols">
                <Field id="tofV" label={`Velocidad (${u.vel})`} />
                <Field id="tofD" label={`Distancia (${u.len})`} />
              </div>
              <button type="button" className="go slim" onClick={() => runBasic('tof')}>Tiempo al objetivo</button>
              <div className="cols">
                <Field id="inM" label={`Masa (${u.mass})`} />
                <Field id="inR" label={`Radio (${system === 'metric' ? 'm' : 'in'})`} />
              </div>
              <button type="button" className="go slim" onClick={() => runBasic('inertia')}>Momento de inercia</button>
              <div className="cols">
                <Field id="fM" label={`Masa (${u.mass})`} />
                <Field id="fA" label="Aceleración (m/s²)" />
              </div>
              <button type="button" className="go slim" onClick={() => runBasic('force')}>Fuerza</button>
            </article>
            <article className="card">
              <h3>Tiro en el vacío y geometría</h3>
              <div className="cols">
                <Field id="trA" label="Ángulo (°)" />
                <Field id="trV" label={`Velocidad (${u.vel})`} />
                <Field id="trX" label="Distancia horizontal (m si métrico, yd si imperial)" />
              </div>
              <button type="button" className="go slim" onClick={() => runBasic('traj')}>Altura de la trayectoria</button>
              <div className="cols">
                <Field id="elH" label="Altura del blanco (m o yd)" />
                <Field id="elD" label="Distancia horizontal" />
              </div>
              <button type="button" className="go slim" onClick={() => runBasic('elev')}>Ángulo de elevación</button>
              <div className="cols">
                <Field id="g1" label={`Masa 1 (${u.mass})`} />
                <Field id="g2" label={`Masa 2 (${u.mass})`} />
                <Field id="gD" label="Distancia" />
              </div>
              <label className="field">
                <span>Unidad de esa distancia</span>
                <select value={val('gU') || 'm'} onChange={(e) => set('gU', e.target.value)}>
                  {Object.keys(lenToM).map((k) => <option key={k} value={k}>{k}</option>)}
                </select>
              </label>
              <button type="button" className="go slim" onClick={() => runBasic('grav')}>Fuerza gravitatoria</button>
              <div className="cols">
                <Field id="coV" label={`Velocidad (${u.vel})`} />
                <Field id="coT" label="Tiempo (s)" />
                <Field id="coA" label="Aceleración lateral (m/s²)" />
              </div>
              <button type="button" className="go slim" onClick={() => runBasic('coriolis')}>Desvío lateral</button>
            </article>
          </Section>

          <Section id="adv" title="Cálculo avanzado de la bala">
            <p className="note">Usa los datos de bala, arma y ambiente de arriba, más la distancia y el ángulo. El rozamiento es una aproximación, no una tabla G1 punto por punto.</p>
            <div className="cols">
              <Field id="aDist" label={`Distancia al blanco (${u.len})`} ph="500" />
              <Field id="aAng" label="Ángulo de salida (°)" ph="0" />
            </div>
            <button type="button" className="go" onClick={runAdvanced}>Calcular solución</button>
          </Section>

          <Section id="out" title="Resultado y trayectoria">
            <pre className="out">{msg}</pre>
            <div className="chart-wrap">
              <canvas ref={canvasRef} width={720} height={320} />
              <div className="zoom">
                <button type="button" onClick={() => setZoom((z) => Math.min(4, z * 1.2))}>+</button>
                <button type="button" onClick={() => setZoom((z) => Math.max(0.4, z / 1.2))}>−</button>
              </div>
            </div>
            <p className="note">La curva roja es el tiro parabólico. El punto blanco marca la distancia pedida. El zoom solo cambia la escala horizontal la próxima vez que dibujes.</p>
          </Section>

          <Section id="hist" title="Historial">
            {history.length === 0 && <p className="note">Aún no hay cálculos en este navegador.</p>}
            <ul className="hist">
              {history.map((h) => (
                <li key={h.id}>
                  <strong>{h.title}</strong>
                  <span>{h.at}</span>
                  <pre>{h.result}</pre>
                </li>
              ))}
            </ul>
            {history.length > 0 && <button type="button" className="ghost full" onClick={() => setHistory([])}>Borrar historial</button>}
          </Section>

          <Section id="explain" title="Qué significa cada cosa">
            <ul className="explain">
              <li><b>MOA.</b> Un minuto de arco. A 100 yardas, 1 MOA mide unas 1.047 pulgadas.</li>
              <li><b>Caída.</b> Lo que la gravedad baja el proyectil durante el tiempo de vuelo. Sin rozamiento es ½gt².</li>
              <li><b>BC.</b> El coeficiente balístico compara el proyectil con un modelo estándar. Aquí solo corrige el arrastre de forma aproximada.</li>
              <li><b>Energía.</b> ½mv² en joules, con la masa en kilogramos y la velocidad en m/s.</li>
              <li><b>SG.</b> Factor de estabilidad de Miller. Por encima de 1.5 el proyectil suele ir estable.</li>
            </ul>
          </Section>
        </main>
      </div>
    </>
  );
}

const CSS = `
.bl-page{min-height:100vh;min-height:100dvh;color:#fff;font-family:var(--font-main,system-ui,sans-serif);background:#07070c url('/images/backgrounds/MA.png') center/cover no-repeat fixed;position:relative}
.bl-page::before{content:'';position:fixed;inset:0;pointer-events:none;background:linear-gradient(180deg,rgba(6,6,10,.42),rgba(6,6,10,.62))}
.bl-head,.bl-main{position:relative;z-index:1}
.bl-head{display:flex;align-items:center;gap:12px;padding:12px 16px;position:sticky;top:0;background:linear-gradient(180deg,rgba(255,255,255,.10),rgba(255,255,255,.03));border-bottom:1px solid rgba(255,255,255,.14);backdrop-filter:blur(26px) saturate(1.6)}
.bl-head h1{flex:1;margin:0;letter-spacing:.16em;text-transform:uppercase;font-size:1rem;color:var(--accent,#ff1a1a)}
.icon,.ghost,.chip,.go{border:1px solid rgba(255,255,255,.16);color:#fff;background:rgba(255,255,255,.07);cursor:pointer;backdrop-filter:blur(10px)}
.icon{width:40px;height:40px;border-radius:14px}
.ghost{border-radius:999px;padding:8px 12px}
.ghost.full{width:100%;border-radius:14px;padding:12px;margin-top:8px}
.bl-main{max-width:980px;margin:0 auto;padding:16px 14px 48px;display:flex;flex-direction:column;gap:12px}
.sec{border-radius:22px;overflow:hidden;border:1px solid rgba(255,255,255,.14);background:linear-gradient(180deg,rgba(255,255,255,.09),rgba(255,255,255,.03));backdrop-filter:blur(18px);box-shadow:inset 0 1px 0 rgba(255,255,255,.2)}
.sec-h{width:100%;display:flex;justify-content:space-between;align-items:center;padding:14px 16px;background:transparent;color:#fff;border:0;cursor:pointer;font-size:1rem;font-weight:700}
.sec-b{padding:0 16px 16px;display:flex;flex-direction:column;gap:12px}
.row{display:flex;gap:8px}
.chip{border-radius:999px;padding:8px 14px}
.chip.on{background:color-mix(in srgb,var(--accent,#ff1a1a) 34%,transparent);border-color:var(--accent,#ff1a1a)}
.note{margin:0;color:rgba(255,255,255,.72);font-size:.86rem;line-height:1.45}
.cols{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:10px}
.field{display:flex;flex-direction:column;gap:6px;font-size:.78rem;color:rgba(255,255,255,.75)}
.field input,.field select{border-radius:12px;padding:11px 12px;border:1px solid rgba(255,255,255,.16);background:rgba(0,0,0,.28);color:#fff;font-size:1rem}
.card{padding:12px;border-radius:16px;border:1px solid rgba(255,255,255,.1);background:rgba(255,255,255,.04);display:flex;flex-direction:column;gap:8px}
.card h3{margin:0;font-size:1rem}
.card p{margin:0;color:rgba(255,255,255,.7);font-size:.84rem}
.go{border-radius:14px;padding:12px;font-weight:750;background:linear-gradient(180deg,color-mix(in srgb,var(--accent,#ff1a1a) 76%,white),color-mix(in srgb,var(--accent,#ff1a1a) 46%,black))}
.go.slim{margin-top:4px}
.out{margin:0;white-space:pre-wrap;font-family:var(--font-mono,ui-monospace,monospace);font-size:.92rem;line-height:1.45;color:#fff}
.chart-wrap{position:relative;border-radius:16px;overflow:hidden;border:1px solid rgba(255,255,255,.12)}
.chart-wrap canvas{width:100%;height:auto;display:block;background:rgba(0,0,0,.25)}
.zoom{position:absolute;top:8px;right:8px;display:flex;gap:6px}
.zoom button{width:36px;height:36px;border-radius:10px;border:0;background:var(--accent,#ff1a1a);color:#fff;cursor:pointer}
.hist{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:8px}
.hist li{padding:10px;border-radius:12px;background:rgba(255,255,255,.05);display:flex;flex-direction:column;gap:4px}
.hist span{font-size:.72rem;color:rgba(255,255,255,.55)}
.hist pre{margin:0;white-space:pre-wrap;font-size:.8rem}
.explain{margin:0;padding-left:18px;color:rgba(255,255,255,.8);line-height:1.5}
.explain b{color:#fff}
`;
