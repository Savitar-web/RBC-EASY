/**
 * pages/Conversion/Conversion.tsx
 * Conversión de datos — glass, fondo TA.png, todas las familias del conversor original
 * y dimensiones separadas donde mezclarlas no tiene sentido físico (V, A, W, actividad vs dosis).
 *
 * Ruta: <Route path="/conversion" element={<Conversion />} />
 * Fondo: coloca TA.png en public/images/backgrounds/TA.png
 *        (antes: Estilos/Assest/TA.png)
 */
import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';

type Unit = { id: string; label: string; factor: number };
type Family = {
  id: string;
  name: string;
  hint: string;
  units: Unit[];
  /** Si existe, el factor es hacia esta unidad base lineal. */
  kind: 'linear' | 'temp' | 'base' | 'sci' | 'tip';
};

const C = 299792458;
const G0 = 9.80665;

const FAMILIES: Family[] = [
  {
    id: 'fuerza', name: 'Fuerza', kind: 'linear',
    hint: 'El kilogramo del conversor anterior se trata como kilogramo-fuerza (kgf = kg · g).',
    units: [
      { id: 'N', label: 'Newton (N)', factor: 1 },
      { id: 'dyn', label: 'Dina (dyn)', factor: 1e-5 },
      { id: 'lbf', label: 'Libra-fuerza (lbf)', factor: 4.4482216152605 },
      { id: 'kgf', label: 'Kilogramo-fuerza (kgf)', factor: G0 },
      { id: 'gf', label: 'Gramo-fuerza (gf)', factor: G0 / 1000 },
      { id: 'mgf', label: 'Miligramo-fuerza (mgf)', factor: G0 / 1e6 },
      { id: 'ozf', label: 'Onza-fuerza (ozf)', factor: 0.278013850953781 },
      { id: 'tf', label: 'Tonelada-fuerza (tf)', factor: G0 * 1000 },
      { id: 'kip', label: 'Kilolibra (kip)', factor: 4448.2216152605 },
    ],
  },
  {
    id: 'masa', name: 'Masa', kind: 'linear',
    hint: 'Masa real, no peso. 1 lb avoirdupois = 0.45359237 kg.',
    units: [
      { id: 'kg', label: 'Kilogramo (kg)', factor: 1 },
      { id: 'g', label: 'Gramo (g)', factor: 1e-3 },
      { id: 'mg', label: 'Miligramo (mg)', factor: 1e-6 },
      { id: 't', label: 'Tonelada (t)', factor: 1000 },
      { id: 'lb', label: 'Libra (lb)', factor: 0.45359237 },
      { id: 'oz', label: 'Onza (oz)', factor: 0.028349523125 },
      { id: 'gr', label: 'Grano (gr)', factor: 6.479891e-5 },
      { id: 'st', label: 'Stone (st)', factor: 6.35029318 },
    ],
  },
  {
    id: 'temp', name: 'Temperatura', kind: 'temp',
    hint: 'Celsius, Fahrenheit, Kelvin y Rankine. El cero absoluto es 0 K.',
    units: [
      { id: 'C', label: 'Celsius (°C)', factor: 1 },
      { id: 'F', label: 'Fahrenheit (°F)', factor: 1 },
      { id: 'K', label: 'Kelvin (K)', factor: 1 },
      { id: 'R', label: 'Rankine (°R)', factor: 1 },
    ],
  },
  {
    id: 'vel', name: 'Velocidad', kind: 'linear',
    hint: 'Mach usa 343 m/s (aire a ~20 °C). c es la velocidad de la luz en el vacío.',
    units: [
      { id: 'mps', label: 'Metros por segundo (m/s)', factor: 1 },
      { id: 'kph', label: 'Kilómetros por hora (km/h)', factor: 1 / 3.6 },
      { id: 'mph', label: 'Millas por hora (mph)', factor: 0.44704 },
      { id: 'kn', label: 'Nudos (kn)', factor: 0.514444 },
      { id: 'mach', label: 'Mach (≈343 m/s)', factor: 343 },
      { id: 'kmps', label: 'Kilómetros por segundo (km/s)', factor: 1000 },
      { id: 'c', label: 'Velocidad de la luz (c)', factor: C },
      { id: 'pc', label: 'Porcentaje de c (%c)', factor: C / 100 },
    ],
  },
  {
    id: 'volt', name: 'Tensión', kind: 'linear',
    hint: 'Solo tensión. Voltios no se convierten a amperios: son magnitudes distintas.',
    units: [
      { id: 'V', label: 'Voltio (V)', factor: 1 },
      { id: 'mV', label: 'Milivoltio (mV)', factor: 1e-3 },
      { id: 'uV', label: 'Microvoltio (µV)', factor: 1e-6 },
      { id: 'kV', label: 'Kilovoltio (kV)', factor: 1e3 },
    ],
  },
  {
    id: 'amp', name: 'Corriente', kind: 'linear',
    hint: 'Solo corriente eléctrica.',
    units: [
      { id: 'A', label: 'Amperio (A)', factor: 1 },
      { id: 'mA', label: 'Miliamperio (mA)', factor: 1e-3 },
      { id: 'uA', label: 'Microamperio (µA)', factor: 1e-6 },
      { id: 'kA', label: 'Kiloamperio (kA)', factor: 1e3 },
    ],
  },
  {
    id: 'pot', name: 'Potencia', kind: 'linear',
    hint: 'Potencia eléctrica y mecánica. 1 hp ≈ 745.7 W.',
    units: [
      { id: 'W', label: 'Watt (W)', factor: 1 },
      { id: 'kW', label: 'Kilowatt (kW)', factor: 1e3 },
      { id: 'MW', label: 'Megawatt (MW)', factor: 1e6 },
      { id: 'hp', label: 'Caballo de fuerza (hp)', factor: 745.699872 },
      { id: 'mW', label: 'Miliwatt (mW)', factor: 1e-3 },
    ],
  },
  {
    id: 'tiempo', name: 'Tiempo', kind: 'linear',
    hint: 'Mes = 30.436875 días medios. Año = 365.25 días. Lustro = 5 años. Eón aquí es 10⁹ años (escala geológica aproximada).',
    units: [
      { id: 's', label: 'Segundo (s)', factor: 1 },
      { id: 'ms', label: 'Milisegundo (ms)', factor: 1e-3 },
      { id: 'us', label: 'Microsegundo (µs)', factor: 1e-6 },
      { id: 'ns', label: 'Nanosegundo (ns)', factor: 1e-9 },
      { id: 'ps', label: 'Picosegundo (ps)', factor: 1e-12 },
      { id: 'fs', label: 'Femtosegundo (fs)', factor: 1e-15 },
      { id: 'as', label: 'Attosegundo (as)', factor: 1e-18 },
      { id: 'min', label: 'Minuto (min)', factor: 60 },
      { id: 'h', label: 'Hora (h)', factor: 3600 },
      { id: 'd', label: 'Día (d)', factor: 86400 },
      { id: 'sem', label: 'Semana (sem)', factor: 604800 },
      { id: 'mes', label: 'Mes medio (mes)', factor: 2.629746e6 },
      { id: 'yr', label: 'Año juliano (yr)', factor: 3.15576e7 },
      { id: 'lus', label: 'Lustro (5 yr)', factor: 1.57788e8 },
      { id: 'dec', label: 'Década (dec)', factor: 3.15576e8 },
      { id: 'sgl', label: 'Siglo (sgl)', factor: 3.15576e9 },
      { id: 'mil', label: 'Milenio (mil)', factor: 3.15576e10 },
      { id: 'eon', label: 'Eón (10⁹ yr)', factor: 3.15576e16 },
    ],
  },
  {
    id: 'acel', name: 'Aceleración', kind: 'linear',
    hint: 'g = 9.80665 m/s². C² es la escala de referencia del proyecto (c²), no una unidad SI cotidiana.',
    units: [
      { id: 'mps2', label: 'm/s²', factor: 1 },
      { id: 'cmps2', label: 'cm/s² (Gal)', factor: 0.01 },
      { id: 'g', label: 'Gravedades (g)', factor: G0 },
      { id: 'ftps2', label: 'ft/s²', factor: 0.3048 },
      { id: 'C2', label: 'Escala c² (m/s²)', factor: C * C },
    ],
  },
  {
    id: 'dens', name: 'Densidad', kind: 'linear',
    hint: 'Base: kg/m³. 1 g/cm³ = 1000 kg/m³.',
    units: [
      { id: 'kgm3', label: 'kg/m³', factor: 1 },
      { id: 'gcm3', label: 'g/cm³', factor: 1000 },
      { id: 'lbft3', label: 'lb/ft³', factor: 16.01846337 },
      { id: 'lbgal', label: 'lb/gal (US)', factor: 119.826427 },
    ],
  },
  {
    id: 'energia', name: 'Energía', kind: 'linear',
    hint: '1 cal = 4.184 J (caloría termoquímica).',
    units: [
      { id: 'J', label: 'Julio (J)', factor: 1 },
      { id: 'kJ', label: 'Kilojulio (kJ)', factor: 1e3 },
      { id: 'cal', label: 'Caloría (cal)', factor: 4.184 },
      { id: 'kcal', label: 'Kilocaloría (kcal)', factor: 4184 },
      { id: 'Wh', label: 'Watt-hora (Wh)', factor: 3600 },
      { id: 'kWh', label: 'Kilowatt-hora (kWh)', factor: 3.6e6 },
      { id: 'eV', label: 'Electronvoltio (eV)', factor: 1.602176634e-19 },
      { id: 'BTU', label: 'BTU (IT)', factor: 1055.05585262 },
    ],
  },
  {
    id: 'long', name: 'Longitud', kind: 'linear',
    hint: 'Base: metro. La pulgada internacional es 0.0254 m exactos.',
    units: [
      { id: 'm', label: 'Metro (m)', factor: 1 },
      { id: 'nm', label: 'Nanómetro (nm)', factor: 1e-9 },
      { id: 'um', label: 'Micrómetro (µm)', factor: 1e-6 },
      { id: 'mm', label: 'Milímetro (mm)', factor: 1e-3 },
      { id: 'cm', label: 'Centímetro (cm)', factor: 0.01 },
      { id: 'km', label: 'Kilómetro (km)', factor: 1000 },
      { id: 'in', label: 'Pulgada (in)', factor: 0.0254 },
      { id: 'ft', label: 'Pie (ft)', factor: 0.3048 },
      { id: 'yd', label: 'Yarda (yd)', factor: 0.9144 },
      { id: 'mi', label: 'Milla (mi)', factor: 1609.344 },
      { id: 'nmi', label: 'Milla náutica (nmi)', factor: 1852 },
    ],
  },
  {
    id: 'vol', name: 'Volumen', kind: 'linear',
    hint: 'Base: litro. 1 m³ = 1000 L. Galón US = 3.785411784 L.',
    units: [
      { id: 'L', label: 'Litro (L)', factor: 1 },
      { id: 'mL', label: 'Mililitro (mL)', factor: 0.001 },
      { id: 'cm3', label: 'Centímetro cúbico (cm³)', factor: 0.001 },
      { id: 'm3', label: 'Metro cúbico (m³)', factor: 1000 },
      { id: 'ft3', label: 'Pie cúbico (ft³)', factor: 28.316846592 },
      { id: 'gal', label: 'Galón US (gal)', factor: 3.785411784 },
      { id: 'floz', label: 'Onza fluida US (fl oz)', factor: 0.0295735295625 },
    ],
  },
  {
    id: 'pres', name: 'Presión', kind: 'linear',
    hint: 'Base: pascal. 1 atm = 101325 Pa. 1 bar = 10⁵ Pa. 1 Torr ≈ 133.322 Pa.',
    units: [
      { id: 'Pa', label: 'Pascal (Pa)', factor: 1 },
      { id: 'kPa', label: 'Kilopascal (kPa)', factor: 1e3 },
      { id: 'bar', label: 'Bar', factor: 1e5 },
      { id: 'atm', label: 'Atmósfera (atm)', factor: 101325 },
      { id: 'Torr', label: 'Torr (mmHg)', factor: 133.322368 },
      { id: 'psi', label: 'psi', factor: 6894.757293168 },
      { id: 'inHg', label: 'Pulgadas de mercurio (inHg)', factor: 3386.389 },
    ],
  },
  {
    id: 'act', name: 'Actividad (radiación)', kind: 'linear',
    hint: 'Becquerel y curie miden desintegraciones, no dosis. 1 Ci = 3.7×10¹⁰ Bq.',
    units: [
      { id: 'Bq', label: 'Becquerel (Bq)', factor: 1 },
      { id: 'kBq', label: 'Kilobecquerel (kBq)', factor: 1e3 },
      { id: 'Ci', label: 'Curie (Ci)', factor: 3.7e10 },
      { id: 'mCi', label: 'Milicurie (mCi)', factor: 3.7e7 },
    ],
  },
  {
    id: 'dosis', name: 'Dosis (radiación)', kind: 'linear',
    hint: 'Gray y sievert no se convierten desde Bq. 1 Gy = 100 rad. 1 Sv = 100 rem (equivalencia numérica de la unidad, no del factor de calidad).',
    units: [
      { id: 'Gy', label: 'Gray (Gy)', factor: 1 },
      { id: 'mGy', label: 'Miligray (mGy)', factor: 1e-3 },
      { id: 'rad', label: 'Rad', factor: 0.01 },
      { id: 'Sv', label: 'Sievert (Sv)', factor: 1 },
      { id: 'mSv', label: 'Milisievert (mSv)', factor: 1e-3 },
      { id: 'rem', label: 'Rem', factor: 0.01 },
    ],
  },
  {
    id: 'datos', name: 'Datos', kind: 'linear',
    hint: 'Prefijos binarios IEC: 1 KiB = 1024 B.',
    units: [
      { id: 'b', label: 'Bit (bit)', factor: 1 / 8 },
      { id: 'B', label: 'Byte (B)', factor: 1 },
      { id: 'KiB', label: 'Kibibyte (KiB)', factor: 1024 },
      { id: 'MiB', label: 'Mebibyte (MiB)', factor: 1024 ** 2 },
      { id: 'GiB', label: 'Gibibyte (GiB)', factor: 1024 ** 3 },
      { id: 'TiB', label: 'Tebibyte (TiB)', factor: 1024 ** 4 },
      { id: 'kB', label: 'Kilobyte decimal (kB)', factor: 1000 },
      { id: 'MB', label: 'Megabyte decimal (MB)', factor: 1e6 },
      { id: 'GB', label: 'Gigabyte decimal (GB)', factor: 1e9 },
    ],
  },
  {
    id: 'ang', name: 'Ángulo', kind: 'linear',
    hint: 'Base: radián.',
    units: [
      { id: 'rad', label: 'Radián (rad)', factor: 1 },
      { id: 'deg', label: 'Grado (°)', factor: Math.PI / 180 },
      { id: 'grad', label: 'Grado centesimal (gon)', factor: Math.PI / 200 },
      { id: 'rev', label: 'Vuelta', factor: Math.PI * 2 },
      { id: 'arcmin', label: 'Minuto de arco (′)', factor: Math.PI / 10800 },
    ],
  },
  {
    id: 'base', name: 'Bases numéricas', kind: 'base',
    hint: 'Binario, octal, decimal y hexadecimal. No uses el punto decimal aquí.',
    units: [
      { id: '2', label: 'Binario (2)', factor: 2 },
      { id: '8', label: 'Octal (8)', factor: 8 },
      { id: '10', label: 'Decimal (10)', factor: 10 },
      { id: '16', label: 'Hexadecimal (16)', factor: 16 },
    ],
  },
  {
    id: 'sci', name: 'Notación científica', kind: 'sci',
    hint: 'Pasa entre decimal largo y notación científica.',
    units: [
      { id: 'dec', label: 'Decimal', factor: 1 },
      { id: 'sci', label: 'Científica', factor: 1 },
    ],
  },
  {
    id: 'tip', name: 'Propinas', kind: 'tip',
    hint: 'Propina y total a partir del monto de la cuenta.',
    units: [
      { id: '10', label: '10%', factor: 10 },
      { id: '15', label: '15%', factor: 15 },
      { id: '18', label: '18%', factor: 18 },
      { id: '20', label: '20%', factor: 20 },
      { id: 'custom', label: 'Otro %', factor: 0 },
    ],
  },
];

function toCelsius(v: number, u: string): number {
  if (u === 'C') return v;
  if (u === 'F') return ((v - 32) * 5) / 9;
  if (u === 'K') return v - 273.15;
  if (u === 'R') return ((v - 491.67) * 5) / 9;
  throw new Error('Unidad térmica desconocida');
}
function fromCelsius(c: number, u: string): number {
  if (u === 'C') return c;
  if (u === 'F') return (c * 9) / 5 + 32;
  if (u === 'K') return c + 273.15;
  if (u === 'R') return (c + 273.15) * (9 / 5);
  throw new Error('Unidad térmica desconocida');
}

function formatNum(n: number): string {
  if (!Number.isFinite(n)) return 'No numérico';
  const abs = Math.abs(n);
  if (n !== 0 && (abs >= 1e12 || abs < 1e-8)) return n.toExponential(8).replace(/\.?0+e/, 'e');
  const s = n.toPrecision(12);
  return s.includes('e') || s.includes('E') ? s : String(Number(s));
}

export default function Conversion() {
  const navigate = useNavigate();
  const [familyId, setFamilyId] = useState('fuerza');
  const family = FAMILIES.find((f) => f.id === familyId) ?? FAMILIES[0];
  const [from, setFrom] = useState(family.units[0].id);
  const [to, setTo] = useState(family.units[1]?.id ?? family.units[0].id);
  const [raw, setRaw] = useState('');
  const [customTip, setCustomTip] = useState('12');
  const [out, setOut] = useState('');
  const [detail, setDetail] = useState('');
  const [err, setErr] = useState('');

  const swapFamily = (id: string) => {
    const next = FAMILIES.find((f) => f.id === id)!;
    setFamilyId(id);
    setFrom(next.units[0].id);
    setTo(next.units[Math.min(1, next.units.length - 1)].id);
    setOut(''); setDetail(''); setErr('');
  };

  const run = () => {
    setErr(''); setOut(''); setDetail('');
    try {
      if (family.kind === 'base') {
        const text = raw.trim();
        if (!text) throw new Error('Escribe un entero en la base de origen.');
        const n = parseInt(text, Number(from));
        if (!Number.isFinite(n)) throw new Error('Ese texto no es válido en la base elegida.');
        const digits = Number(to) === 16 ? n.toString(16).toUpperCase() : n.toString(Number(to));
        setOut(digits);
        setDetail(`Decimal intermedio: ${n}`);
        return;
      }
      if (family.kind === 'sci') {
        const n = Number(String(raw).replace(',', '.'));
        if (!Number.isFinite(n)) throw new Error('Escribe un número.');
        if (to === 'sci' || from === 'dec') {
          setOut(n.toExponential(10));
          setDetail(`Decimal: ${formatNum(n)}`);
        } else {
          setOut(formatNum(n));
          setDetail(`Científica: ${n.toExponential(10)}`);
        }
        if (from === 'sci' && to === 'dec') setOut(formatNum(n));
        if (from === 'dec' && to === 'sci') setOut(n.toExponential(10));
        return;
      }
      if (family.kind === 'tip') {
        const bill = Number(String(raw).replace(',', '.'));
        if (!Number.isFinite(bill) || bill < 0) throw new Error('Monto inválido.');
        const pct = from === 'custom' ? Number(customTip) : Number(from);
        if (!Number.isFinite(pct) || pct < 0) throw new Error('Porcentaje inválido.');
        const tip = (bill * pct) / 100;
        setOut(formatNum(bill + tip));
        setDetail(`Propina ${pct}%: ${formatNum(tip)}`);
        return;
      }
      const value = Number(String(raw).replace(',', '.'));
      if (!Number.isFinite(value)) throw new Error('Escribe un valor numérico.');
      if (family.kind === 'temp') {
        const c = toCelsius(value, from);
        const r = fromCelsius(c, to);
        setOut(formatNum(r));
        setDetail(`Equivalente en Celsius: ${formatNum(c)} °C`);
        return;
      }
      const uf = family.units.find((u) => u.id === from);
      const ut = family.units.find((u) => u.id === to);
      if (!uf || !ut) throw new Error('Unidad no encontrada.');
      const base = value * uf.factor;
      const r = base / ut.factor;
      setOut(formatNum(r));
      setDetail(`${formatNum(value)} ${uf.id}  →  ${formatNum(r)} ${ut.id}`);
    } catch (e) {
      setErr(e instanceof Error ? e.message : 'No se pudo convertir.');
    }
  };

  const preview = useMemo(() => family.hint, [family]);

  return (
    <>
      <style>{CSS}</style>
      <div className="cv-page">
        <header className="cv-head">
          <button type="button" className="icon" onClick={() => navigate('/calcular')} aria-label="Volver">←</button>
          <h1>Conversión</h1>
          <button type="button" className="ghost" onClick={() => navigate('/proyectos')}>Proyectos</button>
        </header>
        <main className="cv-main">
          <p className="lede">Misma imagen de fondo. Cada magnitud se convierte dentro de su propia familia, con factores explícitos.</p>
          <div className="chips" role="tablist">
            {FAMILIES.map((f) => (
              <button key={f.id} type="button" className={f.id === familyId ? 'chip on' : 'chip'} onClick={() => swapFamily(f.id)}>
                {f.name}
              </button>
            ))}
          </div>
          <section className="panel">
            <h2>{family.name}</h2>
            <p className="hint">{preview}</p>
            <div className="grid">
              <label>
                De
                <select value={from} onChange={(e) => setFrom(e.target.value)}>
                  {family.units.map((u) => <option key={u.id} value={u.id}>{u.label}</option>)}
                </select>
              </label>
              <button type="button" className="swap" onClick={() => { const a = from; setFrom(to); setTo(a); }} aria-label="Intercambiar">⇄</button>
              <label>
                A
                <select value={to} onChange={(e) => setTo(e.target.value)}>
                  {family.units.map((u) => <option key={u.id} value={u.id}>{u.label}</option>)}
                </select>
              </label>
            </div>
            <label className="full">
              {family.kind === 'tip' ? 'Monto de la cuenta' : family.kind === 'base' ? 'Valor (texto)' : 'Valor'}
              <input
                value={raw}
                inputMode={family.kind === 'base' ? 'text' : 'decimal'}
                placeholder={family.kind === 'base' ? 'p. ej. FF o 1010' : '0'}
                onChange={(e) => setRaw(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && run()}
              />
            </label>
            {family.kind === 'tip' && from === 'custom' && (
              <label className="full">
                Porcentaje
                <input value={customTip} inputMode="decimal" onChange={(e) => setCustomTip(e.target.value)} />
              </label>
            )}
            <button type="button" className="go" onClick={run}>Convertir</button>
            {err && <p className="err">{err}</p>}
            {out && (
              <div className="result">
                <span className="kicker">{family.kind === 'tip' ? 'Total' : 'Resultado'}</span>
                <strong>{out}</strong>
                {detail && <span className="sub">{detail}</span>}
              </div>
            )}
          </section>
        </main>
      </div>
    </>
  );
}

const CSS = `
.cv-page{
  min-height:100vh;min-height:100dvh;color:#fff;
  font-family:var(--font-main,system-ui,sans-serif);
  background:#07070c url('/images/backgrounds/TA.png') center/cover no-repeat fixed;
  position:relative;
}
.cv-page::before{
  content:'';position:fixed;inset:0;pointer-events:none;
  background:linear-gradient(180deg,rgba(6,6,10,.35),rgba(6,6,10,.55));
}
.cv-head,.cv-main{position:relative;z-index:1}
.cv-head{
  display:flex;align-items:center;gap:12px;padding:12px 16px;
  background:linear-gradient(180deg,rgba(255,255,255,.10),rgba(255,255,255,.03));
  border-bottom:1px solid rgba(255,255,255,.14);
  backdrop-filter:blur(26px) saturate(1.6);
  position:sticky;top:0;
}
.cv-head h1{flex:1;margin:0;font-size:1rem;letter-spacing:.16em;text-transform:uppercase;color:var(--accent,#ff1a1a)}
.icon,.ghost,.chip,.swap,.go{
  border:1px solid rgba(255,255,255,.16);color:#fff;cursor:pointer;
  background:rgba(255,255,255,.07);backdrop-filter:blur(12px);
}
.icon{width:40px;height:40px;border-radius:14px;font-size:1.1rem}
.ghost{border-radius:999px;padding:8px 12px;font-size:.78rem}
.cv-main{max-width:980px;margin:0 auto;padding:18px 16px 40px}
.lede{color:rgba(255,255,255,.78);margin:0 0 14px;line-height:1.45}
.chips{display:flex;flex-wrap:wrap;gap:8px;margin-bottom:14px}
.chip{border-radius:999px;padding:8px 12px;font-size:.78rem;font-weight:650}
.chip.on{background:color-mix(in srgb,var(--accent,#ff1a1a) 32%,transparent);border-color:var(--accent,#ff1a1a)}
.panel{
  border-radius:24px;padding:18px;
  background:linear-gradient(180deg,rgba(255,255,255,.10),rgba(255,255,255,.04));
  border:1px solid rgba(255,255,255,.16);
  box-shadow:inset 0 1px 0 rgba(255,255,255,.25),0 18px 50px rgba(0,0,0,.28);
  backdrop-filter:blur(22px) saturate(1.4);
}
.panel h2{margin:0 0 6px;font-size:1.35rem}
.hint{margin:0 0 14px;color:rgba(255,255,255,.72);font-size:.88rem;line-height:1.45}
.grid{display:grid;grid-template-columns:1fr auto 1fr;gap:10px;align-items:end}
label{display:flex;flex-direction:column;gap:6px;font-size:.78rem;color:rgba(255,255,255,.75)}
.full{margin-top:12px}
select,input{
  width:100%;box-sizing:border-box;border-radius:14px;padding:12px 12px;color:#fff;font-size:1rem;
  border:1px solid rgba(255,255,255,.16);background:rgba(0,0,0,.28);outline:none;
}
select:focus,input:focus{border-color:var(--accent,#ff1a1a);box-shadow:0 0 0 3px color-mix(in srgb,var(--accent,#ff1a1a) 28%,transparent)}
.swap{height:46px;width:46px;border-radius:14px;font-size:1.2rem;margin-bottom:0}
.go{
  margin-top:14px;width:100%;border-radius:16px;padding:14px;font-size:1rem;font-weight:750;
  background:linear-gradient(180deg,color-mix(in srgb,var(--accent,#ff1a1a) 78%,white),color-mix(in srgb,var(--accent,#ff1a1a) 50%,black));
}
.err{color:#ffb4ab;background:rgba(183,28,28,.28);padding:10px 12px;border-radius:12px}
.result{margin-top:14px;padding:16px;border-radius:18px;background:color-mix(in srgb,var(--accent,#ff1a1a) 12%,transparent);border:1px solid color-mix(in srgb,var(--accent,#ff1a1a) 30%,transparent);display:flex;flex-direction:column;gap:4px}
.kicker{font-size:.72rem;letter-spacing:.12em;text-transform:uppercase;color:rgba(255,255,255,.6)}
.result strong{font-size:clamp(1.6rem,4vw,2.4rem);font-variant-numeric:tabular-nums;word-break:break-all}
.sub{color:rgba(255,255,255,.75);font-size:.9rem}
@media(max-width:640px){.grid{grid-template-columns:1fr}.swap{width:100%;height:42px}}
`;
