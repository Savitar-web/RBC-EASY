/**
 * pages/ModoAscendido/ModoAscendido.tsx
 * Calculadora de gráficas, álgebra y matrices. Glass, fondo FMA.png.
 *
 * Ruta: <Route path="/modo-ascendido" element={<ModoAscendido />} />
 * Fondo: public/images/backgrounds/FMA.png  (antes Estilos/Assest/FMA.png)
 */
import { useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';

type Tok =
  | { k: 'n'; v: number }
  | { k: 'id'; v: string }
  | { k: 'op'; v: string }
  | { k: 'lp' } | { k: 'rp' } | { k: 'cm' } | { k: 'fact' };

type Scope = Record<string, number>;
type Ang = 'DEG' | 'RAD';

const FN = new Set(['sin','cos','tan','asin','acos','atan','sinh','cosh','tanh','ln','log','sqrt','cbrt','abs','exp','floor','ceil','round','fact','nthroot','min','max']);

function tokenize(src: string): Tok[] {
  const s = src
    .replace(/π/g, 'pi')
    .replace(/×/g, '*').replace(/÷/g, '/').replace(/−/g, '-')
    .replace(/∛/g, 'cbrt').replace(/∜/g, 'nthroot4').replace(/√/g, 'sqrt');
  const out: Tok[] = [];
  let i = 0;
  const pushImp = () => {
    const p = out[out.length - 1];
    if (!p) return;
    if (p.k === 'n' || p.k === 'rp' || p.k === 'fact' || (p.k === 'id' && !FN.has(p.v))) out.push({ k: 'op', v: '*' });
  };
  while (i < s.length) {
    const c = s[i];
    if (c === ' ' || c === '\n' || c === '\t') { i++; continue; }
    if (c === '(') { pushImp(); out.push({ k: 'lp' }); i++; continue; }
    if (c === ')') { out.push({ k: 'rp' }); i++; continue; }
    if (c === ',') { out.push({ k: 'cm' }); i++; continue; }
    if (c === '!') { out.push({ k: 'fact' }); i++; continue; }
    if ('+-*/^%'.includes(c)) { out.push({ k: 'op', v: c }); i++; continue; }
    if (/[0-9.]/.test(c)) {
      pushImp();
      let j = i + 1;
      while (j < s.length && /[0-9.]/.test(s[j])) j++;
      const num = Number(s.slice(i, j));
      if (!Number.isFinite(num)) throw new Error('Número inválido');
      out.push({ k: 'n', v: num });
      i = j;
      continue;
    }
    if (/[a-zA-Z_]/.test(c)) {
      pushImp();
      let j = i + 1;
      while (j < s.length && /[a-zA-Z0-9_]/.test(s[j])) j++;
      out.push({ k: 'id', v: s.slice(i, j).toLowerCase() });
      i = j;
      continue;
    }
    throw new Error(`Carácter no permitido: ${c}`);
  }
  return out;
}

function factorial(n: number): number {
  if (n < 0 || !Number.isInteger(n) || n > 170) throw new Error('Factorial entero entre 0 y 170');
  let r = 1;
  for (let i = 2; i <= n; i++) r *= i;
  return r;
}

function callFn(name: string, args: number[], ang: Ang): number {
  const toR = (x: number) => (ang === 'DEG' ? (x * Math.PI) / 180 : x);
  const fromR = (x: number) => (ang === 'DEG' ? (x * 180) / Math.PI : x);
  const a = args[0];
  switch (name) {
    case 'sin': return Math.sin(toR(a));
    case 'cos': return Math.cos(toR(a));
    case 'tan': return Math.tan(toR(a));
    case 'asin': return fromR(Math.asin(a));
    case 'acos': return fromR(Math.acos(a));
    case 'atan': return fromR(Math.atan(a));
    case 'sinh': return Math.sinh(a);
    case 'cosh': return Math.cosh(a);
    case 'tanh': return Math.tanh(a);
    case 'ln': return Math.log(a);
    case 'log': return Math.log10(a);
    case 'sqrt': return Math.sqrt(a);
    case 'cbrt': return Math.cbrt(a);
    case 'abs': return Math.abs(a);
    case 'exp': return Math.exp(a);
    case 'floor': return Math.floor(a);
    case 'ceil': return Math.ceil(a);
    case 'round': return Math.round(a);
    case 'fact': return factorial(a);
    case 'nthroot':
    case 'nthroot4': {
      const x = name === 'nthroot4' ? a : a;
      const n = name === 'nthroot4' ? 4 : args[1];
      if (!n) throw new Error('Índice de raíz 0');
      if (x < 0 && n % 2 === 0) throw new Error('Raíz par de un negativo');
      return Math.sign(x) * Math.abs(x) ** (1 / n);
    }
    case 'min': return Math.min(...args);
    case 'max': return Math.max(...args);
    default: throw new Error(`Función desconocida: ${name}`);
  }
}

class Parser {
  i = 0;
  constructor(private tok: Tok[], private scope: Scope, private ang: Ang) {}
  peek() { return this.tok[this.i]; }
  eat() { return this.tok[this.i++]; }
  parse(): number {
    if (!this.tok.length) throw new Error('Expresión vacía');
    const v = this.expr();
    if (this.peek()) throw new Error('Sobran símbolos');
    return v;
  }
  expr(): number {
    let v = this.term();
    while (this.peek()?.k === 'op' && (this.peek() as { v: string }).v.match(/^[+-]$/)) {
      const op = (this.eat() as { v: string }).v;
      const r = this.term();
      v = op === '+' ? v + r : v - r;
    }
    return v;
  }
  term(): number {
    let v = this.power();
    while (this.peek()?.k === 'op' && (this.peek() as { v: string }).v.match(/^[*\\/%]$/)) {
      const op = (this.eat() as { v: string }).v;
      const r = this.power();
      if (op === '*') v *= r;
      else if (op === '/') v /= r;
      else v %= r;
    }
    return v;
  }
  power(): number {
    const base = this.unary();
    if (this.peek()?.k === 'op' && (this.peek() as { v: string }).v === '^') {
      this.eat();
      return base ** this.power();
    }
    return base;
  }
  unary(): number {
    if (this.peek()?.k === 'op' && (this.peek() as { v: string }).v === '-') { this.eat(); return -this.unary(); }
    if (this.peek()?.k === 'op' && (this.peek() as { v: string }).v === '+') { this.eat(); return this.unary(); }
    return this.postfix();
  }
  postfix(): number {
    let v = this.primary();
    while (this.peek()?.k === 'fact') { this.eat(); v = factorial(v); }
    return v;
  }
  primary(): number {
    const t = this.eat();
    if (!t) throw new Error('Expresión incompleta');
    if (t.k === 'n') return t.v;
    if (t.k === 'lp') { const v = this.expr(); if (this.eat()?.k !== 'rp') throw new Error('Falta )'); return v; }
    if (t.k === 'id') {
      if (t.v === 'pi') return Math.PI;
      if (t.v === 'e') return Math.E;
      if (this.peek()?.k === 'lp') {
        this.eat();
        const args: number[] = [];
        if (this.peek()?.k !== 'rp') {
          args.push(this.expr());
          while (this.peek()?.k === 'cm') { this.eat(); args.push(this.expr()); }
        }
        if (this.eat()?.k !== 'rp') throw new Error('Falta )');
        return callFn(t.v, args, this.ang);
      }
      if (t.v in this.scope) return this.scope[t.v];
      throw new Error(`Variable desconocida: ${t.v}`);
    }
    throw new Error('Expresión inválida');
  }
}

function evaluate(expr: string, scope: Scope, ang: Ang): number {
  const v = new Parser(tokenize(expr), scope, ang).parse();
  if (!Number.isFinite(v)) throw new Error('Resultado no numérico');
  return v;
}

function gcd(a: number, b: number): number {
  let x = Math.abs(a); let y = Math.abs(b);
  while (y) { const t = y; y = x % y; x = t; }
  return x || 1;
}

function det(src: number[][]): number {
  const n = src.length;
  const m = src.map((r) => r.slice());
  let sign = 1;
  for (let i = 0; i < n; i++) {
    let piv = i;
    for (let r = i + 1; r < n; r++) if (Math.abs(m[r][i]) > Math.abs(m[piv][i])) piv = r;
    if (Math.abs(m[piv][i]) < 1e-12) return 0;
    if (piv !== i) { const tmp = m[i]; m[i] = m[piv]; m[piv] = tmp; sign *= -1; }
    for (let r = i + 1; r < n; r++) {
      const f = m[r][i] / m[i][i];
      for (let c = i; c < n; c++) m[r][c] -= f * m[i][c];
    }
  }
  return m.reduce((d, row, i) => d * row[i], sign);
}

function inverse(src: number[][]): number[][] {
  const n = src.length;
  const m = src.map((r, i) => [...r, ...Array.from({ length: n }, (_, j) => (i === j ? 1 : 0))]);
  for (let i = 0; i < n; i++) {
    let piv = i;
    for (let r = i + 1; r < n; r++) if (Math.abs(m[r][i]) > Math.abs(m[piv][i])) piv = r;
    if (Math.abs(m[piv][i]) < 1e-12) throw new Error('La matriz no tiene inversa');
    if (piv !== i) { const tmp = m[i]; m[i] = m[piv]; m[piv] = tmp; }
    const div = m[i][i];
    for (let c = 0; c < 2 * n; c++) m[i][c] /= div;
    for (let r = 0; r < n; r++) if (r !== i) {
      const f = m[r][i];
      for (let c = 0; c < 2 * n; c++) m[r][c] -= f * m[i][c];
    }
  }
  return m.map((r) => r.slice(n));
}

function mul(a: number[][], b: number[][]): number[][] {
  if (a[0].length !== b.length) throw new Error('Columnas de A deben igualar filas de B');
  return a.map((row) => b[0].map((_, j) => row.reduce((s, v, k) => s + v * b[k][j], 0)));
}

function matText(m: number[][]): string {
  return m.map((r) => r.map((v) => Number(v.toPrecision(8))).join('\t')).join('\n');
}

type Curve = { expr: string; color: string; relation: boolean };
type Hist = { id: string; expr: string; result: string };

const ADV = [
  'Matrices', 'Derivada', 'Integral', 'Fracciones', 'Cuadrática',
  'Distancia', 'Áreas', 'Estadística', 'Graficar',
] as const;

export default function ModoAscendido() {
  const navigate = useNavigate();
  const box = useRef<HTMLTextAreaElement>(null);
  const canvas = useRef<HTMLCanvasElement>(null);
  const [expr, setExpr] = useState('');
  const [ang, setAng] = useState<Ang>('DEG');
  const [guide, setGuide] = useState('Escribe, mueve el cursor y pulsa =. Las funciones cierran el paréntesis.');
  const [hist, setHist] = useState<Hist[]>([]);
  const [curves, setCurves] = useState<Curve[]>([]);
  const [mats, setMats] = useState<Record<string, number[][]>>({});
  const [panel, setPanel] = useState<string | null>(null);
  const [full, setFull] = useState(false);
  const [xMin, setXMin] = useState('-10');
  const [xMax, setXMax] = useState('10');

  useEffect(() => {
    try {
      const raw = localStorage.getItem('rbc-ascendido-hist');
      if (raw) setHist(JSON.parse(raw));
    } catch { /* ignore */ }
  }, []);
  useEffect(() => {
    try { localStorage.setItem('rbc-ascendido-hist', JSON.stringify(hist.slice(0, 40))); } catch { /* ignore */ }
  }, [hist]);

  const scope = useMemo(() => ({ x: 0, y: 0, z: 0, t: 0, a: 0, b: 0 }), []);

  const insert = (text: string, cursorBack = 0) => {
    const el = box.current;
    const start = el?.selectionStart ?? expr.length;
    const end = el?.selectionEnd ?? expr.length;
    const next = expr.slice(0, start) + text + expr.slice(end);
    setExpr(next);
    requestAnimationFrame(() => {
      if (!el) return;
      el.focus();
      const pos = start + text.length - cursorBack;
      el.setSelectionRange(pos, pos);
    });
  };

  const fn = (name: string) => insert(`${name}()`, 1);

  const calc = () => {
    try {
      const src = expr.trim();
      if (!src) return;
      if (src.includes('=')) { setGuide('Eso parece una ecuación o relación. Usa Graficar o Cuadrática.'); return; }
      const value = evaluate(src, { ...scope }, ang);
      const shown = Number(value.toPrecision(12)).toString();
      setHist((h) => [{ id: `${Date.now()}`, expr: src, result: shown }, ...h].slice(0, 40));
      setExpr(shown);
      setGuide(`${src} = ${shown}`);
    } catch (e) {
      setGuide(e instanceof Error ? e.message : 'Error');
    }
  };

  const paint = (list: Curve[]) => {
    const c = canvas.current;
    if (!c) return;
    const ctx = c.getContext('2d');
    if (!ctx) return;
    const w = c.width;
    const h = c.height;
    ctx.clearRect(0, 0, w, h);
    ctx.fillStyle = 'rgba(6,6,10,0.35)';
    ctx.fillRect(0, 0, w, h);
    const a = Number(xMin);
    const b = Number(xMax);
    if (!Number.isFinite(a) || !Number.isFinite(b) || a === b) return;
    const samples = 240;
    const ys: number[] = [];
    const prepared = list.map((curve) => {
      const row: number[] = [];
      for (let i = 0; i <= samples; i++) {
        const x = a + ((b - a) * i) / samples;
        try {
          let y: number;
          if (curve.relation) {
            const [L, R] = curve.expr.split('=');
            const left = L.trim().toLowerCase();
            y = left === 'y' ? evaluate(R, { x }, ang) : evaluate(`(${R})-(${L})`, { x }, ang);
          } else y = evaluate(curve.expr, { x }, ang);
          row.push(y);
          if (Number.isFinite(y)) ys.push(y);
        } catch { row.push(NaN); }
      }
      return row;
    });
    const minY = ys.length ? Math.min(...ys) : -1;
    const maxY = ys.length ? Math.max(...ys) : 1;
    const pad = 28;
    const y0 = minY === maxY ? minY - 1 : minY;
    const y1 = minY === maxY ? maxY + 1 : maxY;
    const X = (x: number) => pad + ((x - a) / (b - a)) * (w - pad * 2);
    const Y = (y: number) => h - pad - ((y - y0) / (y1 - y0)) * (h - pad * 2);
    ctx.strokeStyle = 'rgba(255,255,255,0.25)';
    ctx.beginPath();
    if (a < 0 && b > 0) { ctx.moveTo(X(0), pad); ctx.lineTo(X(0), h - pad); }
    if (y0 < 0 && y1 > 0) { ctx.moveTo(pad, Y(0)); ctx.lineTo(w - pad, Y(0)); }
    ctx.stroke();
    list.forEach((curve, idx) => {
      ctx.beginPath();
      ctx.strokeStyle = curve.color;
      ctx.lineWidth = 2;
      let started = false;
      prepared[idx].forEach((y, i) => {
        if (!Number.isFinite(y)) { started = false; return; }
        const x = a + ((b - a) * i) / samples;
        if (!started) { ctx.moveTo(X(x), Y(y)); started = true; }
        else ctx.lineTo(X(x), Y(y));
      });
      ctx.stroke();
    });
  };

  useEffect(() => { paint(curves); }, [curves, xMin, xMax, ang, full]);

  const addCurve = (relation: boolean) => {
    const src = expr.trim();
    if (!src) { setGuide('Escribe primero la función.'); return; }
    const color = `hsl(${Math.floor(Math.random() * 360)} 85% 62%)`;
    const next = [...curves, { expr: src, color, relation }];
    setCurves(next);
    setGuide(relation ? 'Relación añadida.' : 'Función añadida.');
    setPanel(null);
  };

  return (
    <>
      <style>{CSS}</style>
      <div className={`ma-page ${full ? 'graph-mode' : ''}`}>
        <header className="ma-head">
          <button type="button" className="icon" onClick={() => navigate('/calcular')}>←</button>
          <h1>Modo ascendido</h1>
          <button type="button" className={ang === 'DEG' ? 'chip on' : 'chip'} onClick={() => setAng((m) => (m === 'DEG' ? 'RAD' : 'DEG'))}>{ang}</button>
          <button type="button" className="ghost" onClick={() => navigate('/proyectos')}>Proyectos</button>
        </header>
        {!full && (
          <main className="ma-main">
            <textarea
              ref={box}
              value={expr}
              spellCheck={false}
              onChange={(e) => setExpr(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); calc(); } }}
              placeholder="0"
              aria-label="Expresión"
            />
            <p className="guide">{guide}</p>
            <div className="pad">
              {[
                ['C', 'clear'], ['⌫', 'del'], ['(', 'text'], [')', 'text'], ['=', 'eq'],
                ['7', 'n'], ['8', 'n'], ['9', 'n'], ['÷', '/'], ['×', '*'],
                ['4', 'n'], ['5', 'n'], ['6', 'n'], ['+', '+'], ['−', '-'],
                ['1', 'n'], ['2', 'n'], ['3', 'n'], ['%', '%'], ['.', '.'],
                ['0', 'n'], ['π', 'pi'], ['e', 'e'], ['x', 'x'], ['^', '^'],
                ['sin', 'sin'], ['cos', 'cos'], ['tan', 'tan'], ['ln', 'ln'], ['log', 'log'],
                ['√', 'sqrt'], ['∛', 'cbrt'], ['n!', 'fact'], ['exp', 'exp'], ['ƒ', 'adv'],
              ].map(([label, action]) => (
                <button
                  key={label + action}
                  type="button"
                  className={`key ${action === 'eq' ? 'eq' : ''} ${['sin','cos','tan','ln','log','sqrt','cbrt','fact','exp','adv'].includes(action) ? 'fn' : ''}`}
                  onClick={() => {
                    if (action === 'clear') { setExpr(''); setGuide('Pantalla limpia.'); return; }
                    if (action === 'del') {
                      const el = box.current;
                      const s = el?.selectionStart ?? expr.length;
                      const e = el?.selectionEnd ?? expr.length;
                      if (s !== e) setExpr(expr.slice(0, s) + expr.slice(e));
                      else if (s > 0) setExpr(expr.slice(0, s - 1) + expr.slice(e));
                      return;
                    }
                    if (action === 'eq') { calc(); return; }
                    if (action === 'adv') { setPanel('menu'); return; }
                    if (action === 'sin' || action === 'cos' || action === 'tan' || action === 'ln' || action === 'log' || action === 'sqrt' || action === 'cbrt' || action === 'exp') { fn(action); return; }
                    if (action === 'fact') { insert('!'); return; }
                    if (action === 'pi') { insert('π'); return; }
                    if (action === 'text') { insert(label); return; }
                    insert(action === 'n' || action === 'x' || action === 'e' ? label : action === '/' ? '/' : action === '*' ? '*' : action === '+' ? '+' : action === '-' ? '-' : action === '%' ? '%' : action === '.' ? '.' : action === '^' ? '^' : label);
                  }}
                >{label}</button>
              ))}
            </div>
            <div className="tools">
              <button type="button" onClick={() => addCurve(expr.includes('='))}>Graficar</button>
              <button type="button" onClick={() => setFull(true)}>Pantalla de gráfica</button>
              <button type="button" onClick={() => setPanel('menu')}>Avanzado</button>
              <button type="button" onClick={() => { setCurves([]); setGuide('Gráficas borradas.'); }}>Limpiar curvas</button>
            </div>
            <div className="range">
              <label>x mín <input value={xMin} onChange={(e) => setXMin(e.target.value)} /></label>
              <label>x máx <input value={xMax} onChange={(e) => setXMax(e.target.value)} /></label>
            </div>
            <canvas ref={canvas} width={900} height={280} className="plot" />
            <ul className="legend">
              {curves.map((c, i) => (
                <li key={i}><i style={{ background: c.color }} />{c.expr}
                  <button type="button" onClick={() => setCurves(curves.filter((_, j) => j !== i))}>✕</button>
                </li>
              ))}
            </ul>
            <section className="hist">
              <h2>Historial</h2>
              {hist.length === 0 && <p>Sin cuentas todavía.</p>}
              {hist.map((h) => (
                <button key={h.id} type="button" className="hitem" onClick={() => setExpr(h.expr)}>
                  <span>{h.expr}</span><strong>{h.result}</strong>
                </button>
              ))}
            </section>
          </main>
        )}
        {full && (
          <div className="fullgraph">
            <canvas ref={canvas} width={1200} height={700} className="plot big" />
            <div className="float">
              <button type="button" onClick={() => setFull(false)}>Salir</button>
              <label>x mín <input value={xMin} onChange={(e) => setXMin(e.target.value)} /></label>
              <label>x máx <input value={xMax} onChange={(e) => setXMax(e.target.value)} /></label>
            </div>
          </div>
        )}
        {panel && (
          <div className="overlay" onClick={() => setPanel(null)} role="presentation">
            <div className="modal" onClick={(e) => e.stopPropagation()} role="dialog">
              <div className="mhead">
                <h2>{panel === 'menu' ? 'Avanzado' : panel}</h2>
                <button type="button" className="icon" onClick={() => setPanel(null)}>✕</button>
              </div>
              {panel === 'menu' && (
                <div className="menu">
                  {ADV.map((name) => (
                    <button key={name} type="button" onClick={() => setPanel(name)}>{name}</button>
                  ))}
                </div>
              )}
              {panel === 'Matrices' && <MatrixPanel mats={mats} setMats={setMats} onResult={(t) => { setExpr(t); setGuide(t); }} />}
              {panel === 'Derivada' && <DerivativePanel ang={ang} onResult={(t) => { setGuide(t); setExpr(t); }} />}
              {panel === 'Integral' && <IntegralPanel ang={ang} onResult={(t) => { setGuide(t); setExpr(t); }} />}
              {panel === 'Fracciones' && <FractionPanel onResult={(t) => { setExpr(t); setGuide(t); }} />}
              {panel === 'Cuadrática' && <QuadPanel onResult={(t) => { setExpr(t); setGuide(t); }} />}
              {panel === 'Distancia' && <DistancePanel onResult={(t) => { setExpr(t); setGuide(t); }} />}
              {panel === 'Áreas' && <AreaPanel onResult={(t) => { setExpr(t); setGuide(t); }} />}
              {panel === 'Estadística' && <StatPanel onResult={(t) => { setExpr(t); setGuide(t); }} />}
              {panel === 'Graficar' && (
                <div className="stack">
                  <p>Se usa lo que haya en la pantalla. Si tiene un signo = se trata como relación f(x)=0.</p>
                  <button type="button" className="go" onClick={() => addCurve(false)}>Añadir y=f(x)</button>
                  <button type="button" className="go" onClick={() => addCurve(true)}>Añadir relación</button>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </>
  );
}

function useFields(keys: string[]) {
  const [v, setV] = useState<Record<string, string>>(() => Object.fromEntries(keys.map((k) => [k, ''])));
  const field = (key: string, label: string) => (
    <label key={key} className="field"><span>{label}</span>
      <input value={v[key] ?? ''} onChange={(e) => setV((s) => ({ ...s, [key]: e.target.value }))} />
    </label>
  );
  return { v, field };
}

function MatrixPanel({ mats, setMats, onResult }: { mats: Record<string, number[][]>; setMats: (m: Record<string, number[][]>) => void; onResult: (t: string) => void }) {
  const [name, setName] = useState('A');
  const [rows, setRows] = useState(2);
  const [cols, setCols] = useState(2);
  const [grid, setGrid] = useState<string[][]>([['0', '0'], ['0', '0']]);
  const [other, setOther] = useState('B');
  const resize = (r: number, c: number) => {
    setRows(r); setCols(c);
    setGrid(Array.from({ length: r }, (_, i) => Array.from({ length: c }, (_, j) => grid[i]?.[j] ?? '0')));
  };
  const save = () => {
    const m = grid.map((row) => row.map((cell) => Number(cell)));
    if (m.some((row) => row.some((n) => !Number.isFinite(n)))) { onResult('Hay celdas vacías'); return; }
    setMats({ ...mats, [name]: m });
    onResult(`Matriz ${name} guardada`);
  };
  return (
    <div className="stack">
      <p>Hasta 4×4. Determinante, inversa y producto usan las matrices guardadas por nombre.</p>
      <div className="range">
        <label>Nombre <input value={name} onChange={(e) => setName(e.target.value || 'A')} /></label>
        <label>Filas <input value={rows} onChange={(e) => resize(Math.max(1, Math.min(4, Number(e.target.value) || 1)), cols)} /></label>
        <label>Columnas <input value={cols} onChange={(e) => resize(rows, Math.max(1, Math.min(4, Number(e.target.value) || 1)))} /></label>
      </div>
      <div className="mgrid" style={{ gridTemplateColumns: `repeat(${cols}, 1fr)` }}>
        {grid.flatMap((row, i) => row.map((cell, j) => (
          <input key={`${i}-${j}`} value={cell} onChange={(e) => {
            const next = grid.map((r) => r.slice());
            next[i][j] = e.target.value;
            setGrid(next);
          }} />
        )))}
      </div>
      <button type="button" className="go" onClick={save}>Guardar</button>
      <div className="range">
        <button type="button" onClick={() => { const m = mats[name]; if (!m || m.length !== m[0].length) { onResult('Hace falta una matriz cuadrada'); return; } onResult(String(det(m))); }}>det({name})</button>
        <button type="button" onClick={() => { try { const m = mats[name]; if (!m) throw new Error('No existe'); onResult(matText(inverse(m))); } catch (e) { onResult(e instanceof Error ? e.message : 'Error'); } }}>inversa</button>
      </div>
      <label className="field">Segunda matriz
        <input value={other} onChange={(e) => setOther(e.target.value)} />
      </label>
      <button type="button" className="go" onClick={() => { try { if (!mats[name] || !mats[other]) throw new Error('Faltan matrices'); onResult(matText(mul(mats[name], mats[other]))); } catch (e) { onResult(e instanceof Error ? e.message : 'Error'); } }}>Producto {name}·{other}</button>
      <p>{Object.keys(mats).length ? `Guardadas: ${Object.keys(mats).join(', ')}` : 'Ninguna guardada.'}</p>
    </div>
  );
}

function DerivativePanel({ ang, onResult }: { ang: Ang; onResult: (t: string) => void }) {
  const { v, field } = useFields(['expr', 'x0']);
  return (
    <div className="stack">
      <p>Derivada numérica centrada en x₀, paso 1e-4. Úsala sobre y = f(x).</p>
      {field('expr', 'f(x)')}
      {field('x0', 'x₀')}
      <button type="button" className="go" onClick={() => {
        try {
          const x0 = Number(v.x0 || '0');
          const h = 1e-4;
          const d = (evaluate(v.expr, { x: x0 + h }, ang) - evaluate(v.expr, { x: x0 - h }, ang)) / (2 * h);
          onResult(String(Number(d.toPrecision(8))));
        } catch (e) { onResult(e instanceof Error ? e.message : 'Error'); }
      }}>Derivar</button>
    </div>
  );
}

function IntegralPanel({ ang, onResult }: { ang: Ang; onResult: (t: string) => void }) {
  const { v, field } = useFields(['expr', 'a', 'b']);
  return (
    <div className="stack">
      <p>Integral definida por trapecios, 200 intervalos.</p>
      {field('expr', 'f(x)')}{field('a', 'Límite inferior')}{field('b', 'Límite superior')}
      <button type="button" className="go" onClick={() => {
        try {
          const a = Number(v.a); const b = Number(v.b);
          const n = 200; const h = (b - a) / n;
          let s = 0.5 * (evaluate(v.expr, { x: a }, ang) + evaluate(v.expr, { x: b }, ang));
          for (let i = 1; i < n; i++) s += evaluate(v.expr, { x: a + i * h }, ang);
          onResult(String(Number((s * h).toPrecision(8))));
        } catch (e) { onResult(e instanceof Error ? e.message : 'Error'); }
      }}>Integrar</button>
    </div>
  );
}

function FractionPanel({ onResult }: { onResult: (t: string) => void }) {
  const { v, field } = useFields(['n', 'd', 'n2', 'd2']);
  return (
    <div className="stack">
      <p>Simplifica una fracción o suma dos. Los signos se conservan en el numerador.</p>
      {field('n', 'Numerador')}{field('d', 'Denominador')}
      <button type="button" className="go" onClick={() => {
        const n0 = Math.trunc(Number(v.n)); const d0 = Math.trunc(Number(v.d));
        if (!d0) { onResult('Denominador 0'); return; }
        const g = gcd(n0, d0);
        onResult(`${n0 / g}/${d0 / g}`);
      }}>Simplificar</button>
      {field('n2', 'Numerador 2')}{field('d2', 'Denominador 2')}
      <button type="button" className="go" onClick={() => {
        const a = Math.trunc(Number(v.n)); const b = Math.trunc(Number(v.d));
        const c = Math.trunc(Number(v.n2)); const d = Math.trunc(Number(v.d2));
        if (!b || !d) { onResult('Denominador 0'); return; }
        const n0 = a * d + c * b; const d0 = b * d; const g = gcd(n0, d0);
        onResult(`${n0 / g}/${d0 / g}`);
      }}>Sumar</button>
    </div>
  );
}

function QuadPanel({ onResult }: { onResult: (t: string) => void }) {
  const { v, field } = useFields(['a', 'b', 'c']);
  return (
    <div className="stack">
      <p>ax² + bx + c = 0. Si el discriminante es negativo, entrega la parte real y la imaginaria.</p>
      {field('a', 'a')}{field('b', 'b')}{field('c', 'c')}
      <button type="button" className="go" onClick={() => {
        const a = Number(v.a); const b = Number(v.b); const c = Number(v.c);
        if (!a) { onResult('a no puede ser 0'); return; }
        const disc = b * b - 4 * a * c;
        if (disc >= 0) {
          const r = Math.sqrt(disc);
          onResult(`x₁ = ${((-b + r) / (2 * a)).toPrecision(8)}, x₂ = ${((-b - r) / (2 * a)).toPrecision(8)}`);
        } else {
          const r = Math.sqrt(-disc);
          onResult(`x = ${(-b / (2 * a)).toPrecision(6)} ± ${(r / (2 * a)).toPrecision(6)} i`);
        }
      }}>Resolver</button>
    </div>
  );
}

function DistancePanel({ onResult }: { onResult: (t: string) => void }) {
  const { v, field } = useFields(['x1', 'y1', 'x2', 'y2']);
  return (
    <div className="stack">
      {field('x1', 'x₁')}{field('y1', 'y₁')}{field('x2', 'x₂')}{field('y2', 'y₂')}
      <button type="button" className="go" onClick={() => {
        const d = Math.hypot(Number(v.x2) - Number(v.x1), Number(v.y2) - Number(v.y1));
        onResult(String(Number(d.toPrecision(10))));
      }}>Distancia</button>
    </div>
  );
}

function AreaPanel({ onResult }: { onResult: (t: string) => void }) {
  const { v, field } = useFields(['base', 'altura', 'radio', 'largo', 'ancho']);
  return (
    <div className="stack">
      {field('base', 'Base')}{field('altura', 'Altura')}
      <button type="button" className="go" onClick={() => onResult(String((Number(v.base) * Number(v.altura)) / 2))}>Triángulo</button>
      {field('radio', 'Radio')}
      <button type="button" className="go" onClick={() => onResult(String(Math.PI * Number(v.radio) ** 2))}>Círculo</button>
      {field('largo', 'Largo')}{field('ancho', 'Ancho')}
      <button type="button" className="go" onClick={() => onResult(String(Number(v.largo) * Number(v.ancho)))}>Rectángulo</button>
    </div>
  );
}

function StatPanel({ onResult }: { onResult: (t: string) => void }) {
  const [raw, setRaw] = useState('1, 2, 3, 4');
  const data = () => raw.split(/[,;\s]+/).map(Number).filter((n) => Number.isFinite(n));
  return (
    <div className="stack">
      <label className="field">Datos separados por comas
        <input value={raw} onChange={(e) => setRaw(e.target.value)} />
      </label>
      <button type="button" className="go" onClick={() => { const d = data(); if (!d.length) return; onResult(String(d.reduce((a, b) => a + b, 0) / d.length)); }}>Media</button>
      <button type="button" className="go" onClick={() => {
        const d = data().slice().sort((a, b) => a - b);
        if (!d.length) return;
        const mid = Math.floor(d.length / 2);
        onResult(String(d.length % 2 ? d[mid] : (d[mid - 1] + d[mid]) / 2));
      }}>Mediana</button>
      <button type="button" className="go" onClick={() => {
        const d = data();
        if (d.length < 2) { onResult('Hacen falta al menos 2 datos'); return; }
        const m = d.reduce((a, b) => a + b, 0) / d.length;
        const s = Math.sqrt(d.reduce((a, b) => a + (b - m) ** 2, 0) / (d.length - 1));
        onResult(String(Number(s.toPrecision(8))));
      }}>Desviación muestral</button>
    </div>
  );
}

const CSS = `
.ma-page{min-height:100vh;min-height:100dvh;color:#fff;font-family:var(--font-main,system-ui,sans-serif);background:#07070c url('/images/backgrounds/FMA.png') center/cover no-repeat fixed;position:relative}
.ma-page::before{content:'';position:fixed;inset:0;pointer-events:none;background:linear-gradient(180deg,rgba(6,6,10,.4),rgba(6,6,10,.58))}
.ma-head,.ma-main,.fullgraph{position:relative;z-index:1}
.ma-head{display:flex;align-items:center;gap:10px;padding:12px 16px;position:sticky;top:0;background:linear-gradient(180deg,rgba(255,255,255,.1),rgba(255,255,255,.03));border-bottom:1px solid rgba(255,255,255,.14);backdrop-filter:blur(24px) saturate(1.6)}
.ma-head h1{flex:1;margin:0;font-size:1rem;letter-spacing:.14em;text-transform:uppercase;color:var(--accent,#ff1a1a)}
.icon,.ghost,.chip,.key,.tools button,.go,.menu button,.hitem{color:#fff;cursor:pointer}
.icon{width:40px;height:40px;border-radius:14px;border:1px solid rgba(255,255,255,.16);background:rgba(255,255,255,.08)}
.ghost,.chip{border-radius:999px;padding:8px 12px;border:1px solid rgba(255,255,255,.16);background:rgba(255,255,255,.07)}
.chip.on{background:color-mix(in srgb,var(--accent,#ff1a1a) 34%,transparent);border-color:var(--accent,#ff1a1a)}
.ma-main{max-width:920px;margin:0 auto;padding:14px 12px 40px;display:flex;flex-direction:column;gap:10px}
textarea{width:100%;box-sizing:border-box;min-height:92px;resize:vertical;border-radius:20px;padding:16px;text-align:right;font-size:1.45rem;font-family:var(--font-mono,ui-monospace,monospace);color:#fff;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.16);backdrop-filter:blur(16px);outline:none}
.guide{margin:0;text-align:right;color:rgba(255,255,255,.72);font-size:.82rem}
.pad{display:grid;grid-template-columns:repeat(5,1fr);gap:8px}
.key{min-height:58px;border-radius:16px;border:1px solid rgba(255,255,255,.16);background:linear-gradient(180deg,rgba(255,255,255,.16),rgba(255,255,255,.05));font-size:1.15rem;font-weight:700;box-shadow:inset 0 1px 0 rgba(255,255,255,.28)}
.key.fn{font-size:.95rem;background:linear-gradient(180deg,rgba(120,170,255,.18),rgba(255,255,255,.04))}
.key.eq{background:linear-gradient(180deg,color-mix(in srgb,var(--accent,#ff1a1a) 78%,white),color-mix(in srgb,var(--accent,#ff1a1a) 48%,black))}
.tools,.range{display:flex;flex-wrap:wrap;gap:8px}
.tools button,.go,.menu button{border-radius:14px;padding:12px 14px;border:1px solid rgba(255,255,255,.16);background:rgba(255,255,255,.08)}
.range label,.field{display:flex;flex-direction:column;gap:4px;font-size:.75rem;color:rgba(255,255,255,.72);flex:1}
.range input,.field input,.mgrid input{border-radius:12px;padding:10px;border:1px solid rgba(255,255,255,.16);background:rgba(0,0,0,.28);color:#fff}
.plot{width:100%;height:auto;border-radius:18px;border:1px solid rgba(255,255,255,.14);background:rgba(0,0,0,.2)}
.legend{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:6px}
.legend li{display:flex;align-items:center;gap:8px;font-family:var(--font-mono,ui-monospace,monospace);font-size:.82rem}
.legend i{width:12px;height:12px;border-radius:99px;display:block}
.legend button{margin-left:auto;border:0;background:transparent;color:#fff;cursor:pointer}
.hist h2{margin:0;font-size:.78rem;letter-spacing:.12em;text-transform:uppercase;color:var(--accent,#ff1a1a)}
.hitem{width:100%;text-align:left;border-radius:12px;padding:8px 10px;border:1px solid rgba(255,255,255,.1);background:rgba(255,255,255,.05);display:flex;flex-direction:column}
.overlay{position:fixed;inset:0;z-index:30;background:rgba(0,0,0,.45);backdrop-filter:blur(8px);display:flex;align-items:center;justify-content:center;padding:16px}
.modal{width:min(560px,100%);max-height:min(86vh,760px);overflow:auto;border-radius:22px;padding:14px;background:linear-gradient(180deg,rgba(28,28,34,.78),rgba(12,12,16,.7));border:1px solid rgba(255,255,255,.16);backdrop-filter:blur(24px)}
.mhead{display:flex;justify-content:space-between;align-items:center}
.mhead h2{margin:0;font-size:1.1rem}
.menu{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:12px}
.stack{display:flex;flex-direction:column;gap:8px}
.stack p{margin:0;color:rgba(255,255,255,.75);line-height:1.4}
.mgrid{display:grid;gap:6px}
.fullgraph{min-height:calc(100dvh - 64px);padding:12px}
.float{position:absolute;top:76px;left:20px;display:flex;gap:8px;align-items:end;padding:10px;border-radius:16px;background:rgba(0,0,0,.28);backdrop-filter:blur(12px)}
@media(min-width:900px){.key{min-height:68px;font-size:1.3rem}}
@media(max-width:640px){.menu{grid-template-columns:1fr}.key{min-height:48px}}
`;
