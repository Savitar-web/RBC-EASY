import { Routes, Route } from 'react-router-dom';
import { ThemeProvider } from './hooks/useTheme';
import Home from './pages/Home/Home';
import Projects from './pages/Projects/Projects';
import Contact from './pages/Contact/Contact';
import BibliasMaker from './pages/BibliasMaker/BibliasMaker';
import Writer from './pages/Writer/Writer';
import Calcular from './pages/Calcular/Calcular';
import ModoAscendido from './pages/ModoAscendido/ModoAscendido';
import Conversion from './pages/Conversion/Conversion';
import Balistica from './pages/Balistica/Balistica';

function App() {
  return (
    <ThemeProvider>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/proyectos" element={<Projects />} />
        <Route path="/contacto" element={<Contact />} />

        <Route path="/proyectos" element={<Projects />} />
        <Route path="/biblias" element={<BibliasMaker />} />
        <Route path="/Writer" element={<Writer />} />
        <Route path="/calcular" element={<Calcular />} />
        <Route path="/modo-ascendido" element={<ModoAscendido />} />
        <Route path="/conversion" element={<Conversion />} />
        <Route path="/balistica" element={<Balistica />} />
      </Routes>
    </ThemeProvider>
  );
}

export default App;